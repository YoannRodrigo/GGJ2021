# tvOS Wwise Unity Build module
import BuildUtil
import BuildWwiseUnityIntegration
import GenerateApiBinding
import collections
import os
import shutil
from os import path
from BuildWwiseUnityIntegration import XCodeBuilder
from GenerateApiBinding import AppleSwigCommand
from PrepareSwigInput import SwigPlatformHandlerPOSIX, SwigApiHeaderBlobber, PlatformStructProfile

class tvOSBuilder(XCodeBuilder):
	def __init__(self, platformName, arches, configs, generateSwig, generatePremake):
		XCodeBuilder.__init__(self, platformName, arches, configs, generateSwig, generatePremake)

class tvOSSwigCommand(AppleSwigCommand):
	def __init__(self, pathMan):
		AppleSwigCommand.__init__(self, pathMan)

		self.platformDefines += ['-DAK_IOS', '-DTARGET_OS_TV', '-DTARGET_OS_EMBEDDED', '-D__arm__'] # No need for -D__arm64__. __arm__ is good enough for fixing header includes on iOS7.
		self.dllName = ['-dllimport', '__Internal']

		self.platformSdkName = 'AppleTVOS'
		self.SdkCompatibilityNodes = collections.OrderedDict() # Nodes in the "greater and equal too" sense.
		self._InitPlatformSdkInfo()

class SwigApiHeaderBlobbertvOS(SwigApiHeaderBlobber):
	def __init__(self, pathMan):
		SwigApiHeaderBlobber.__init__(self, pathMan)

		self.inputHeaders.append(path.normpath(path.join(self.SdkIncludeDir, 'AK/SoundEngine/Platforms/iOS/AkiOSSoundEngine.h')))

class SwigPlatformHandlertvOS(SwigPlatformHandlerPOSIX):
	def __init__(self, pathMan):
		SwigPlatformHandlerPOSIX.__init__(self, pathMan)

		AudioSessionPropertyHeader = 'AK/SoundEngine/Platforms/iOS/AkiOSSoundEngine.h'
		AudioSessionRegEx = '(struct[ \t]+AkAudioSessionProperties)([\w\W]*?)(\};)'
		self.PlatformStructProfiles += \
		[
			PlatformStructProfile(self.pathMan, AudioSessionPropertyHeader, AudioSessionRegEx)
		]

	def CopyPlatformSdkSourceFiles(self):
		SwigPlatformHandlerPOSIX.CopyPlatformSdkSourceFiles(self)

def Init(argv=None):
	BuildUtil.BankPlatforms['tvOS'] = 'tvOS'
	BuildUtil.SupportedArches['tvOS'] = ['armeabi-v7a', 'arm64-v8a', 'x86']
	BuildUtil.PremakeParameters['tvOS'] = { 'os': 'tvos', 'generator': 'xcode4' }
	BuildUtil.PlatformSwitches['tvOS'] = '#if UNITY_TVOS && ! UNITY_EDITOR'
	BuildUtil.PlatformDependentFilenames.append('AkAudioSessionCategory.cs')
	BuildUtil.PlatformDependentFilenames.append('AkAudioSessionCategoryOptions.cs')
	BuildUtil.PlatformDependentFilenames.append('AkAudioSessionMode.cs')
	BuildUtil.PlatformDependentFilenames.append('AkAudioSessionProperties.cs')
	BuildUtil.PlatformDependentFilenames.append('AkAudioSessionSetActiveOptions.cs')
	BuildUtil.SupportedPlatforms['Darwin'].append('tvOS')

def CreatePlatformBuilder(platformName, arches, configs, generateSwig, generatePremake):
	return tvOSBuilder(platformName, arches, configs, generateSwig, generatePremake)

def CreateSwigCommand(pathMan, arch):
	return tvOSSwigCommand(pathMan)

def CreateSwigPlatformHandler(pathMan):
	return SwigPlatformHandlertvOS(pathMan)

def CreateSwigApiHeaderBlobber(pathMan):
	return SwigApiHeaderBlobbertvOS(pathMan)

if __name__ == '__main__':
	pass
