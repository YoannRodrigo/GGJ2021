# GX Wwise Unity Build Module
import BuildUtil
import BuildWwiseUnityIntegration
import GenerateApiBinding
from os import path
from BuildWwiseUnityIntegration import VS2017Builder
from GenerateApiBinding import SwigCommand
from PrepareSwigInput import SwigPlatformHandler, SwigApiHeaderBlobber, PlatformStructProfile

class GXBuilder(VS2017Builder):
	def __init__(self, platformName, arches, configs, generateSwig, generatePremake):
		VS2017Builder.__init__(self, platformName, arches, configs, generateSwig, generatePremake)

		self.FixedArch = 'GX'

class GXSwigCommand(SwigCommand):
	def __init__(self, pathMan):
		SwigCommand.__init__(self, pathMan)

		self.platformDefines = ['-D_GAMING_XBOX_XBOXONE', '-DAK_GAMINGXBOX', '-DAK_XBOX', '-DAK_SUPPORT_WCHAR']

class SwigApiHeaderBlobberGX(SwigApiHeaderBlobber):
	def __init__(self, pathMan):
		SwigApiHeaderBlobber.__init__(self, pathMan)

		self.inputHeaders.append(path.normpath(path.join(self.SdkIncludeDir, 'AK/SoundEngine/Platforms/GX/AkGXSoundEngine.h')))

class SwigPlatformHandlerGX(SwigPlatformHandler):
	def __init__(self, pathMan):
		SwigPlatformHandler.__init__(self, pathMan)

		ThreadPropertyHeader = 'AK/Tools/Win32/AkPlatformFuncs.h'
		self.PlatformStructProfiles += \
		[
			PlatformStructProfile(self.pathMan, ThreadPropertyHeader, SwigPlatformHandler.ThreadPropertiesRegEx)
		]

		self.ioFileSources = \
		[
			path.join(self.pathMan.Paths['Wwise_SDK_Samples'], path.normpath('SoundEngine/Win32/stdafx.cpp')),
			path.join(self.pathMan.Paths['Wwise_SDK_Samples'], path.normpath('SoundEngine/Win32/stdafx.h')),
			path.join(self.pathMan.Paths['Wwise_SDK_Samples'], path.normpath('SoundEngine/Win32/AkFileHelpers.h')),
			path.join(self.pathMan.Paths['Wwise_SDK_Samples'], path.normpath('SoundEngine/Win32/AkDefaultIOHookBlocking.cpp')),
			path.join(self.pathMan.Paths['Wwise_SDK_Samples'], path.normpath('SoundEngine/Win32/AkDefaultIOHookBlocking.h')),
			path.join(self.pathMan.Paths['Wwise_SDK_Samples'], path.normpath('SoundEngine/Win32/AkFilePackageLowLevelIOBlocking.h'))
		]

def Init(argv=None):
	BuildUtil.BankPlatforms['GX'] = 'GX'
	BuildUtil.SupportedArches['GX'] = ['x64']
	BuildUtil.PremakeParameters['GX'] = { 'os': 'gx', 'generator': 'vs2017' }
	BuildUtil.PlatformSwitches['GX'] = '#if UNITY_GAMECORE_XBOXONE && ! UNITY_EDITOR'
	BuildUtil.SupportedPlatforms['Windows'].append('GX')

def CreatePlatformBuilder(platformName, arches, configs, generateSwig, generatePremake):
	return GXBuilder(platformName, arches, configs, generateSwig, generatePremake)

def CreateSwigCommand(pathMan, arch):
	return GXSwigCommand(pathMan)

def CreateSwigPlatformHandler(pathMan):
	return SwigPlatformHandlerGX(pathMan)

def CreateSwigApiHeaderBlobber(pathMan):
	return SwigApiHeaderBlobberGX(pathMan)

if __name__ == '__main__':
	pass
