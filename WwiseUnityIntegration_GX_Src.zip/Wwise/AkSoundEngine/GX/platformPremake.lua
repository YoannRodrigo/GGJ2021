-- GX Unity premake module
local platform = {}

function platform.setupTargetAndLibDir(baseTargetDir)
    targetdir(baseTargetDir .. "GX/%{cfg.buildcfg}")
    libdirs(wwiseSDKEnv .. "/GX" .. GetSuffixFromCurrentAction() .. "/%{cfg.buildcfg}/lib")
end

function platform.platformSpecificConfiguration()
    links {
        "acphal",
        "MMDevApi"
    }

    linkoptions {
        "/WINMD:NO"
    }

    filter "Debug* or Profile*"
        links {
            "ws2_32",
        }
end

return platform