﻿#if UNITY_XBOXONE && !UNITY_EDITOR
public partial class AkBasePathGetter
{
	static string DefaultPlatformName = "XboxOne";
}
#endif